# Flarix Studio Welcome Bot - ONE Message

The join notification and embed are now in ONE Discord message.

The message content is outside the embed:

<:welcome:1554255628988588052> @User has joined the server!

The same Discord message also contains the complete embed with:

- Flarix Studio header
- Server logo thumbnail
- Custom server emojis
- Inviter information
- Invite stats
- Invite code
- Important Channels
- Account Details
- Animated banner.gif

This is done with one Discord send:

channel.send(
    content=join_text,
    embed=embed,
    files=files
)

Files:

images/banner.gif
images/server-logo.png

Channel IDs:

Welcome: 1554209704371167392
Rules: 1502907786034417664
IGN Whitelist: 1554077137433137212
Recording Plans: 1554075373833293946

Install:
pip install -r requirements.txt

Run:
python main.py
