import os
from datetime import datetime, timezone

import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")

SERVER_NAME = "Flarix Studio"
BRAND_COLOR = 0x1877F2

WELCOME_CHANNEL_ID = 1554209704371167392
RULES_CHANNEL_ID = 1502907786034417664
IGN_WHITELIST_CHANNEL_ID = 1554077137433137212
RECORDING_PLANS_CHANNEL_ID = 1554075373833293946

# ============================================================
# CUSTOM EMOJI IDs
#
# IMPORTANT:
# We use the emoji ID and fetch the real Discord Emoji object
# instead of manually sending <:name:id>. This fixes cases where
# Discord displays :emoji_name: instead of the actual emoji,
# including animated emojis whose syntax is different.
# ============================================================

EMOJI_IDS = {
    "welcome": 1554255628988588052,
    "rules": 1502927246078509066,
    "whitelist": 1503571546655166605,
    "recording": 1502928298609737859,
    "important": 1502927805799989330,
    "account": 1554257709539266660,
    "invited": 1554255678577582090,
    "stats": 1554255714669699122,
    "invite_code": 1554255824698876036,
    "dots": 1554258311724011530,
}

# Unicode fallbacks are used ONLY if an emoji cannot be accessed.
# They prevent broken :emoji_name: text from appearing.
EMOJI_FALLBACKS = {
    "welcome": "👋",
    "rules": "📖",
    "whitelist": "📜",
    "recording": "🎥",
    "important": "📌",
    "account": "📖",
    "invited": "🤝",
    "stats": "📊",
    "invite_code": "🔗",
    "dots": "•",
}

custom_emojis = {}


async def load_custom_emojis(guild: discord.Guild):
    """Load the real Emoji objects from the Discord server."""
    try:
        emojis = await guild.fetch_emojis()
    except (discord.Forbidden, discord.HTTPException):
        emojis = guild.emojis

    custom_emojis.clear()

    available_ids = {emoji.id for emoji in emojis}

    for key, emoji_id in EMOJI_IDS.items():
        emoji = next(
            (item for item in emojis if item.id == emoji_id),
            None
        )

        if emoji is not None:
            custom_emojis[key] = emoji
            print(
                f"[EMOJI] {key}: "
                f"{emoji} | id={emoji.id} | animated={emoji.animated}"
            )
        else:
            print(
                f"[EMOJI MISSING] {key}: "
                f"id={emoji_id} is not accessible to this bot."
            )

    missing = [
        key for key, emoji_id in EMOJI_IDS.items()
        if emoji_id not in available_ids
    ]

    if missing:
        print(
            "[EMOJI WARNING] Missing custom emojis: "
            + ", ".join(missing)
        )
        print(
            "[EMOJI WARNING] Make sure these emojis are in the "
            "same server and the bot is allowed to use them."
        )


def emoji(key: str) -> str:
    """Return the real Discord emoji markup or a clean fallback."""
    value = custom_emojis.get(key)

    if value is not None:
        # str(Emoji) automatically produces:
        # <:name:id> for static emojis
        # <a:name:id> for animated emojis
        return str(value)

    return EMOJI_FALLBACKS.get(key, "•")


intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(
    command_prefix="!",
    intents=intents,
    help_command=None
)

invite_cache = {}


def account_age(created_at: datetime) -> str:
    days = max(
        0,
        (datetime.now(timezone.utc) - created_at).days
    )

    if days == 0:
        return "Less than 1 day"

    if days == 1:
        return "1 day"

    return f"{days} days"


def joined_date(member: discord.Member) -> str:
    if not member.joined_at:
        return "Unknown"

    return member.joined_at.strftime(
        "%B %d, %Y at %I:%M %p"
    )


async def refresh_invites():
    for guild in bot.guilds:
        try:
            invites = await guild.invites()

            invite_cache[guild.id] = {
                invite.code: invite.uses or 0
                for invite in invites
            }

        except (discord.Forbidden, discord.HTTPException):
            invite_cache[guild.id] = {}


async def get_used_invite(guild: discord.Guild):
    try:
        invites = await guild.invites()
    except (discord.Forbidden, discord.HTTPException):
        return None, None

    old = invite_cache.get(guild.id, {})

    used_invite = None
    new_uses = None

    for invite in invites:
        current = invite.uses or 0
        previous = old.get(invite.code, 0)

        if current > previous:
            used_invite = invite
            new_uses = current
            break

    invite_cache[guild.id] = {
        invite.code: invite.uses or 0
        for invite in invites
    }

    return used_invite, new_uses


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} ({bot.user.id})")

    for guild in bot.guilds:
        print(
            f"Loading custom emojis from: "
            f"{guild.name} ({guild.id})"
        )
        await load_custom_emojis(guild)

    await refresh_invites()

    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name=SERVER_NAME
        )
    )

    print(f"{SERVER_NAME} welcome bot is online.")


@bot.event
async def on_invite_create(invite: discord.Invite):
    try:
        invites = await invite.guild.invites()

        invite_cache[invite.guild.id] = {
            item.code: item.uses or 0
            for item in invites
        }

    except (discord.Forbidden, discord.HTTPException):
        pass


@bot.event
async def on_member_join(member: discord.Member):
    channel = bot.get_channel(WELCOME_CHANNEL_ID)

    if channel is None:
        print("Welcome channel not found.")
        return

    # Refresh in case the guild's emoji cache changed.
    await load_custom_emojis(member.guild)

    used_invite, new_uses = await get_used_invite(member.guild)

    inviter_text = "Unknown"
    invite_stats_text = "Unavailable"
    invite_code_text = "Unavailable"

    if used_invite:
        if used_invite.inviter:
            inviter_text = used_invite.inviter.mention

        invite_stats_text = (
            f"{new_uses} total uses"
            if new_uses is not None
            else "Unavailable"
        )

        invite_code_text = used_invite.code

    # ============================================================
    # EMBED
    # ============================================================

    embed = discord.Embed(
        color=BRAND_COLOR
    )

    if member.guild.icon:
        embed.set_author(
            name=f"{SERVER_NAME}™ | Minecraft YouTube",
            icon_url=member.guild.icon.url
        )
    else:
        embed.set_author(
            name=f"{SERVER_NAME}™ | Minecraft YouTube"
        )

    embed.set_thumbnail(
        url="attachment://server-logo.png"
    )

    embed.add_field(
        name=(
            f"{emoji('welcome')} "
            f"Hello {member.display_name}!"
        ),
        value=(
            f"{emoji('welcome')} "
            f"Welcome {member.mention} to **{SERVER_NAME}™!**"
        ),
        inline=False
    )

    embed.add_field(
        name="",
        value=(
            f"{emoji('invited')} **Invited by:** {inviter_text}\n"
            f"{emoji('stats')} **Invite stats:** {invite_stats_text}\n"
            f"{emoji('invite_code')} **Invite code used:** "
            f"`{invite_code_text}`"
        ),
        inline=False
    )

    embed.add_field(
        name=(
            f"{emoji('important')} "
            f"Important Channels"
        ),
        value=(
            f"{emoji('dots')} {emoji('rules')} "
            f"<#{RULES_CHANNEL_ID}>\n"
            f"{emoji('dots')} {emoji('whitelist')} "
            f"<#{IGN_WHITELIST_CHANNEL_ID}>\n"
            f"{emoji('dots')} {emoji('recording')} "
            f"<#{RECORDING_PLANS_CHANNEL_ID}>"
        ),
        inline=False
    )

    embed.add_field(
        name=(
            f"{emoji('account')} "
            f"Account Details"
        ),
        value=(
            f"{emoji('dots')} Joined: "
            f"{joined_date(member)}\n"
            f"{emoji('dots')} Account Age: "
            f"{account_age(member.created_at)}\n"
            f"{emoji('dots')} Member Count: "
            f"{member.guild.member_count:,}"
        ),
        inline=False
    )

    # Animated banner
    embed.set_image(
        url="attachment://banner.gif"
    )

    files = []

    logo_path = os.path.join(
        "images",
        "server-logo.png"
    )

    banner_path = os.path.join(
        "images",
        "banner.gif"
    )

    if os.path.isfile(logo_path):
        files.append(
            discord.File(
                logo_path,
                filename="server-logo.png"
            )
        )
    else:
        print(
            "Missing images/server-logo.png"
        )

    if os.path.isfile(banner_path):
        files.append(
            discord.File(
                banner_path,
                filename="banner.gif"
            )
        )
    else:
        print(
            "Missing images/banner.gif"
        )

    # ============================================================
    # ONE DISCORD MESSAGE
    #
    # Join notification stays OUTSIDE the embed but is attached
    # to the exact same Discord message.
    # ============================================================

    join_text = (
        f"{emoji('welcome')} "
        f"{member.mention} has joined the server!"
    )

    try:
        await channel.send(
            content=join_text,
            embed=embed,
            files=files if files else None
        )

        print(
            f"Welcome message sent for {member}."
        )

    except discord.Forbidden:
        print(
            "Missing Discord permissions. "
            "Required: View Channel, Send Messages, "
            "Embed Links and Attach Files."
        )

    except discord.HTTPException as e:
        print(
            f"Discord API error: {e}"
        )


if not TOKEN:
    raise RuntimeError(
        "DISCORD_TOKEN is missing from .env"
    )

bot.run(TOKEN)
